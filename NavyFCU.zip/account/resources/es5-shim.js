﻿// vim:set ts=4 sts=4 sw=4 st:
// -- kriskowal Kris Kowal Copyright (C) 2009-2010 MIT License
// -- tlrobinson Tom Robinson Copyright (C) 2009-2010 MIT License (Narwhal Project)
// -- dantman Daniel Friesen Copyright(C) 2010 XXX No License Specified
// -- fschaefer Florian Schäfer Copyright (C) 2010 MIT License
// -- Irakli Gozalishvili Copyright (C) 2010 MIT License

/*!
Copyright (c) 2009, 280 North Inc. http://280north.com/
MIT License. http://github.com/280north/narwhal/blob/master/README.md
*/

(typeof define === "function" ? define : function ($) { $(); })(function (require, exports, module, undefined) {

    /**
    * Brings an environment as close to ECMAScript 5 compliance
    * as is possible with the facilities of erstwhile engines.
    *
    * ES5 Draft
    * http://www.ecma-international.org/publications/files/drafts/tc39-2009-050.pdf
    *
    * NOTE: this is a draft, and as such, the URL is subject to change.  If the
    * link is broken, check in the parent directory for the latest TC39 PDF.
    * http://www.ecma-international.org/publications/files/drafts/
    *
    * Previous ES5 Draft
    * http://www.ecma-international.org/publications/files/drafts/tc39-2009-025.pdf
    * This is a broken link to the previous draft of ES5 on which most of the
    * numbered specification references and quotes herein were taken.  Updating
    * these references and quotes to reflect the new document would be a welcome
    * volunteer project.
    *
    * @module
    */

    /*whatsupdoc*/

    //
    // Function
    // ========
    //

    // ES-5 15.3.4.5
    // http://www.ecma-international.org/publications/files/drafts/tc39-2009-025.pdf

    if (!Function.prototype.bind) {
        var slice = Array.prototype.slice;
        Function.prototype.bind = function bind(that) { // .length is 1
            // 1. Let Target be the this value.
            var target = this;
            // 2. If IsCallable(Target) is false, throw a TypeError exception.
            // XXX this gets pretty close, for all intents and purposes, letting
            // some duck-types slide
            if (typeof target.apply !== "function" || typeof target.call !== "function")
                return new TypeError();
            // 3. Let A be a new (possibly empty) internal list of all of the
            //   argument values provided after thisArg (arg1, arg2 etc), in order.
            var args = slice.call(arguments);
            // 4. Let F be a new native ECMAScript object.
            // 9. Set the [[Prototype]] internal property of F to the standard
            //   built-in Function prototype object as specified in 15.3.3.1.
            // 10. Set the [[Call]] internal property of F as described in
            //   15.3.4.5.1.
            // 11. Set the [[Construct]] internal property of F as described in
            //   15.3.4.5.2.
            // 12. Set the [[HasInstance]] internal property of F as described in
            //   15.3.4.5.3.
            // 13. The [[Scope]] internal property of F is unused and need not
            //   exist.
            function bound() {

                if (this instanceof bound) {
                    // 15.3.4.5.2 [[Construct]]
                    // When the [[Construct]] internal method of a function object,
                    // F that was created using the bind function is called with a
                    // list of arguments ExtraArgs the following steps are taken:
                    // 1. Let target be the value of F's [[TargetFunction]]
                    //   internal property.
                    // 2. If target has no [[Construct]] internal method, a
                    //   TypeError exception is thrown.
                    // 3. Let boundArgs be the value of F's [[BoundArgs]] internal
                    //   property.
                    // 4. Let args be a new list containing the same values as the
                    //   list boundArgs in the same order followed by the same
                    //   values as the list ExtraArgs in the same order.

                    var self = Object.create(target.prototype);
                    target.apply(self, args.concat(slice.call(arguments)));
                    return self;

                } else {
                    // 15.3.4.5.1 [[Call]]
                    // When the [[Call]] internal method of a function object, F,
                    // which was created using the bind function is called with a
                    // this value and a list of arguments ExtraArgs the following
                    // steps are taken:
                    // 1. Let boundArgs be the value of F's [[BoundArgs]] internal
                    //   property.
                    // 2. Let boundThis be the value of F's [[BoundThis]] internal
                    //   property.
                    // 3. Let target be the value of F's [[TargetFunction]] internal
                    //   property.
                    // 4. Let args be a new list containing the same values as the list
                    //   boundArgs in the same order followed by the same values as
                    //   the list ExtraArgs in the same order. 5.  Return the
                    //   result of calling the [[Call]] internal method of target
                    //   providing boundThis as the this value and providing args
                    //   as the arguments.

                    // equiv: target.call(this, ...boundArgs, ...args)
                    return target.call.apply(
                    target,
                    args.concat(slice.call(arguments))
                );

                }

            }
            bound.length = (
            // 14. If the [[Class]] internal property of Target is "Function", then
            typeof target === "function" ?
            // a. Let L be the length property of Target minus the length of A.
            // b. Set the length own property of F to either 0 or L, whichever is larger.
            Math.max(target.length - args.length, 0) :
            // 15. Else set the length own property of F to 0.
            0
        );
            // 16. The length own property of F is given attributes as specified in
            //   15.3.5.1.
            // TODO
            // 17. Set the [[Extensible]] internal property of F to true.
            // TODO
            // 18. Call the [[DefineOwnProperty]] internal method of F with
            //   arguments "caller", PropertyDescriptor {[[Value]]: null,
            //   [[Writable]]: false, [[Enumerable]]: false, [[Configurable]]:
            //   false}, and false.
            // TODO
            // 19. Call the [[DefineOwnProperty]] internal method of F with
            //   arguments "arguments", PropertyDescriptor {[[Value]]: null,
            //   [[Writable]]: false, [[Enumerable]]: false, [[Configurable]]:
            //   false}, and false.
            // TODO
            // NOTE Function objects created using Function.prototype.bind do not
            // have a prototype property.
            // XXX can't delete it in pure-js.
            return bound;
        };
    }

    // Shortcut to an often accessed properties, in order to avoid multiple
    // dereference that costs universally.
    // _Please note: Shortcuts are defined after `Function.prototype.bind` as we
    // us it in defining shortcuts.
    var call = Function.prototype.call;
    var prototypeOfArray = Array.prototype;
    var prototypeOfObject = Object.prototype;
    var owns = call.bind(prototypeOfObject.hasOwnProperty);

    var defineGetter, defineSetter, lookupGetter, lookupSetter, supportsAccessors;
    // If JS engine supports accessors creating shortcuts.
    if ((supportsAccessors = owns(prototypeOfObject, '__defineGetter__'))) {
        defineGetter = call.bind(prototypeOfObject.__defineGetter__);
        defineSetter = call.bind(prototypeOfObject.__defineSetter__);
        lookupGetter = call.bind(prototypeOfObject.__lookupGetter__);
        lookupSetter = call.bind(prototypeOfObject.__lookupSetter__);
    }


    //
    // Array
    // =====
    //

    // ES5 15.4.3.2
    if (!Array.isArray) {
        Array.isArray = function isArray(obj) {
            return Object.prototype.toString.call(obj) === "[object Array]";
        };
    }

    // ES5 15.4.4.18
    if (!Array.prototype.forEach) {
        Array.prototype.forEach = function forEach(block, thisObject) {
            var len = +this.length;
            for (var i = 0; i < len; i++) {
                if (i in this) {
                    block.call(thisObject, this[i], i, this);
                }
            }
        };
    }

    // ES5 15.4.4.19
    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/map
    if (!Array.prototype.map) {
        Array.prototype.map = function map(fun /*, thisp*/) {
            var len = +this.length;
            if (typeof fun !== "function")
                throw new TypeError();

            var res = new Array(len);
            var thisp = arguments[1];
            for (var i = 0; i < len; i++) {
                if (i in this)
                    res[i] = fun.call(thisp, this[i], i, this);
            }

            return res;
        };
    }

    // ES5 15.4.4.20
    if (!Array.prototype.filter) {
        Array.prototype.filter = function filter(block /*, thisp */) {
            var values = [];
            var thisp = arguments[1];
            for (var i = 0; i < this.length; i++)
                if (block.call(thisp, this[i]))
                    values.push(this[i]);
            return values;
        };
    }

    // ES5 15.4.4.16
    if (!Array.prototype.every) {
        Array.prototype.every = function every(block /*, thisp */) {
            var thisp = arguments[1];
            for (var i = 0; i < this.length; i++)
                if (!block.call(thisp, this[i]))
                    return false;
            return true;
        };
    }

    // ES5 15.4.4.17
    if (!Array.prototype.some) {
        Array.prototype.some = function some(block /*, thisp */) {
            var thisp = arguments[1];
            for (var i = 0; i < this.length; i++)
                if (block.call(thisp, this[i]))
                    return true;
            return false;
        };
    }

    // ES5 15.4.4.21
    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/reduce
    if (!Array.prototype.reduce) {
        Array.prototype.reduce = function reduce(fun /*, initial*/) {
            var len = +this.length;
            if (typeof fun !== "function")
                throw new TypeError();

            // no value to return if no initial value and an empty array
            if (len === 0 && arguments.length === 1)
                throw new TypeError();

            var i = 0;
            if (arguments.length >= 2) {
                var rv = arguments[1];
            } else {
                do {
                    if (i in this) {
                        rv = this[i++];
                        break;
                    }

                    // if array contains no values, no initial value to return
                    if (++i >= len)
                        throw new TypeError();
                } while (true);
            }

            for (; i < len; i++) {
                if (i in this)
                    rv = fun.call(null, rv, this[i], i, this);
            }

            return rv;
        };
    }

    // ES5 15.4.4.22
    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/reduceRight
    if (!Array.prototype.reduceRight) {
        Array.prototype.reduceRight = function reduceRight(fun /*, initial*/) {
            var len = +this.length;
            if (typeof fun !== "function")
                throw new TypeError();

            // no value to return if no initial value, empty array
            if (len === 0 && arguments.length === 1)
                throw new TypeError();

            var rv, i = len - 1;
            if (arguments.length >= 2) {
                rv = arguments[1];
            } else {
                do {
                    if (i in this) {
                        rv = this[i--];
                        break;
                    }

                    // if array contains no values, no initial value to return
                    if (--i < 0)
                        throw new TypeError();
                } while (true);
            }

            for (; i >= 0; i--) {
                if (i in this)
                    rv = fun.call(null, rv, this[i], i, this);
            }

            return rv;
        };
    }

    // ES5 15.4.4.14
    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function indexOf(value /*, fromIndex */) {
            var length = this.length;
            if (!length)
                return -1;
            var i = arguments[1] || 0;
            if (i >= length)
                return -1;
            if (i < 0)
                i += length;
            for (; i < length; i++) {
                if (!owns(this, i))
                    continue;
                if (value === this[i])
                    return i;
            }
            return -1;
        };
    }

    // ES5 15.4.4.15
    if (!Array.prototype.lastIndexOf) {
        Array.prototype.lastIndexOf = function lastIndexOf(value /*, fromIndex */) {
            var length = this.length;
            if (!length)
                return -1;
            var i = arguments[1] || length;
            if (i < 0)
                i += length;
            i = Math.min(i, length - 1);
            for (; i >= 0; i--) {
                if (!owns(this, i))
                    continue;
                if (value === this[i])
                    return i;
            }
            return -1;
        };
    }

    //
    // Object
    // ======
    //

    // ES5 15.2.3.2
    if (!Object.getPrototypeOf) {
        // https://github.com/kriskowal/es5-shim/issues#issue/2
        // http://ejohn.org/blog/objectgetprototypeof/
        // recommended by fschaefer on github
        Object.getPrototypeOf = function getPrototypeOf(object) {
            return object.__proto__ || object.constructor.prototype;
            // or undefined if not available in this engine
        };
    }

    // ES5 15.2.3.3
    if (!Object.getOwnPropertyDescriptor) {
        var ERR_NON_OBJECT = "Object.getOwnPropertyDescriptor called on a " +
                         "non-object: ";
        Object.getOwnPropertyDescriptor = function getOwnPropertyDescriptor(object, property) {
            if ((typeof object !== "object" && typeof object !== "function") || object === null)
                throw new TypeError(ERR_NON_OBJECT + object);
            // If object does not owns property return undefined immediately.
            if (!owns(object, property))
                return undefined;

            var despriptor, getter, setter;

            // If object has a property then it's for sure both `enumerable` and
            // `configurable`.
            despriptor = { enumerable: true, configurable: true };

            // If JS engine supports accessor properties then property may be a
            // getter or setter.
            if (supportsAccessors) {
                // Unfortunately `__lookupGetter__` will return a getter even
                // if object has own non getter property along with a same named
                // inherited getter. To avoid misbehavior we temporary remove
                // `__proto__` so that `__lookupGetter__` will return getter only
                // if it's owned by an object.
                var prototype = object.__proto__;
                object.__proto__ = prototypeOfObject;

                var getter = lookupGetter(object, property);
                var setter = lookupSetter(object, property);

                // Once we have getter and setter we can put values back.
                object.__proto__ = prototype;

                if (getter || setter) {
                    if (getter) descriptor.get = getter;
                    if (setter) descriptor.set = setter;

                    // If it was accessor property we're done and return here
                    // in order to avoid adding `value` to the descriptor.
                    return descriptor;
                }
            }

            // If we got this far we know that object has an own property that is
            // not an accessor so we set it as a value and return descriptor.
            descriptor.value = object[property];
            return descriptor;
        };
    }

    // ES5 15.2.3.4
    if (!Object.getOwnPropertyNames) {
        Object.getOwnPropertyNames = function getOwnPropertyNames(object) {
            return Object.keys(object);
        };
    }

    // ES5 15.2.3.5
    if (!Object.create) {
        Object.create = function create(prototype, properties) {
            var object;
            if (prototype === null) {
                object = { "__proto__": null };
            } else {
                if (typeof prototype !== "object")
                    throw new TypeError("typeof prototype[" + (typeof prototype) + "] != 'object'");
                var Type = function () { };
                Type.prototype = prototype;
                object = new Type();
                // IE has no built-in implementation of `Object.getPrototypeOf`
                // neither `__proto__`, but this manually setting `__proto__` will
                // guarantee that `Object.getPrototypeOf` will work as expected with
                // objects created using `Object.create`
                object.__proto__ = prototype;
            }
            if (typeof properties !== "undefined")
                Object.defineProperties(object, properties);
            return object;
        };
    }

    // ES5 15.2.3.6
    if (!Object.defineProperty) {
        var ERR_NON_OBJECT_DESCRIPTOR = "Property description must be an object: ";
        var ERR_NON_OBJECT_TARGET = "Object.defineProperty called on non-object: "
        var ERR_ACCESSORS_NOT_SUPPORTED = "getters & setters can not be defined " +
                                      "on this javascript engine";

        Object.defineProperty = function defineProperty(object, property, descriptor) {
            if (typeof object !== "object" && typeof object !== "function")
                throw new TypeError(ERR_NON_OBJECT_TARGET + object);
            if (typeof object !== "object" || object === null)
                throw new TypeError(ERR_NON_OBJECT_DESCRIPTOR + descriptor);

            // If it's a data property.
            if (owns(descriptor, "value")) {
                // fail silently if "writable", "enumerable", or "configurable"
                // are requested but not supported
                /*
                // alternate approach:
                if ( // can't implement these features; allow false but not true
                !(owns(descriptor, "writable") ? descriptor.writable : true) ||
                !(owns(descriptor, "enumerable") ? descriptor.enumerable : true) ||
                !(owns(descriptor, "configurable") ? descriptor.configurable : true)
                )
                throw new RangeError(
                "This implementation of Object.defineProperty does not " +
                "support configurable, enumerable, or writable."
                );
                */

                if (supportsAccessors && (lookupGetter(object, property) ||
                                      lookupSetter(object, property))) {
                    // As accessors are supported only on engines implementing
                    // `__proto__` we can safely override `__proto__` while defining
                    // a property to make sure that we don't hit an inherited
                    // accessor.
                    var prototype = object.__proto__;
                    object.__proto__ = prototypeOfObject;
                    // Deleting a property anyway since getter / setter may be
                    // defined on object itself.
                    delete object[property];
                    object[property] = descriptor.value;
                    // Setting original `__proto__` back now.
                    object.prototype;
                } else {
                    object[property] = descriptor.value;
                }
            } else {
                if (!supportsAccessors)
                    throw new TypeError(ERR_ACCESSORS_NOT_SUPPORTED);
                // If we got that far then getters and setters can be defined !!
                if (owns(descriptor, "get"))
                    defineGetter(object, property, descriptor.get);
                if (owns(descriptor, "set"))
                    defineSetter(object, property, descriptor.set);
            }

            return object;
        };
    }

    // ES5 15.2.3.7
    if (!Object.defineProperties) {
        Object.defineProperties = function defineProperties(object, properties) {
            for (var property in properties) {
                if (owns(properties, property))
                    Object.defineProperty(object, property, properties[property]);
            }
            return object;
        };
    }

    // ES5 15.2.3.8
    if (!Object.seal) {
        Object.seal = function seal(object) {
            // this is misleading and breaks feature-detection, but
            // allows "securable" code to "gracefully" degrade to working
            // but insecure code.
            return object;
        };
    }

    // ES5 15.2.3.9
    if (!Object.freeze) {
        Object.freeze = function freeze(object) {
            // this is misleading and breaks feature-detection, but
            // allows "securable" code to "gracefully" degrade to working
            // but insecure code.
            return object;
        };
    }

    // detect a Rhino bug and patch it
    try {
        Object.freeze(function () { });
    } catch (exception) {
        Object.freeze = (function freeze(freezeObject) {
            return function freeze(object) {
                if (typeof object === "function") {
                    return object;
                } else {
                    return freezeObject(object);
                }
            };
        })(Object.freeze);
    }

    // ES5 15.2.3.10
    if (!Object.preventExtensions) {
        Object.preventExtensions = function preventExtensions(object) {
            // this is misleading and breaks feature-detection, but
            // allows "securable" code to "gracefully" degrade to working
            // but insecure code.
            return object;
        };
    }

    // ES5 15.2.3.11
    if (!Object.isSealed) {
        Object.isSealed = function isSealed(object) {
            return false;
        };
    }

    // ES5 15.2.3.12
    if (!Object.isFrozen) {
        Object.isFrozen = function isFrozen(object) {
            return false;
        };
    }

    // ES5 15.2.3.13
    if (!Object.isExtensible) {
        Object.isExtensible = function isExtensible(object) {
            return true;
        };
    }

    // ES5 15.2.3.14
    // http://whattheheadsaid.com/2010/10/a-safer-object-keys-compatibility-implementation
    if (!Object.keys) {

        var hasDontEnumBug = true,
        dontEnums = [
            'toString',
            'toLocaleString',
            'valueOf',
            'hasOwnProperty',
            'isPrototypeOf',
            'propertyIsEnumerable',
            'constructor'
        ],
        dontEnumsLength = dontEnums.length;

        for (var key in { "toString": null })
            hasDontEnumBug = false;

        Object.keys = function keys(object) {

            if (
            typeof object !== "object" && typeof object !== "function"
            || object === null
        )
                throw new TypeError("Object.keys called on a non-object");

            var keys = [];
            for (var name in object) {
                if (owns(object, name)) {
                    keys.push(name);
                }
            }

            if (hasDontEnumBug) {
                for (var i = 0, ii = dontEnumsLength; i < ii; i++) {
                    var dontEnum = dontEnums[i];
                    if (owns(object, dontEnum)) {
                        keys.push(dontEnum);
                    }
                }
            }

            return keys;
        };

    }

    //
    // Date
    // ====
    //

    // ES5 15.9.5.43
    // Format a Date object as a string according to a subset of the ISO-8601 standard.
    // Useful in Atom, among other things.
    if (!Date.prototype.toISOString) {
        Date.prototype.toISOString = function toISOString() {
            return (
            this.getUTCFullYear() + "-" +
            (this.getUTCMonth() + 1) + "-" +
            this.getUTCDate() + "T" +
            this.getUTCHours() + ":" +
            this.getUTCMinutes() + ":" +
            this.getUTCSeconds() + "Z"
        );
        }
    }

    // ES5 15.9.4.4
    if (!Date.now) {
        Date.now = function now() {
            return new Date().getTime();
        };
    }

    // ES5 15.9.5.44
    if (!Date.prototype.toJSON) {
        Date.prototype.toJSON = function toJSON(key) {
            // This function provides a String representation of a Date object for
            // use by JSON.stringify (15.12.3). When the toJSON method is called
            // with argument key, the following steps are taken:

            // 1.  Let O be the result of calling ToObject, giving it the this
            // value as its argument.
            // 2. Let tv be ToPrimitive(O, hint Number).
            // 3. If tv is a Number and is not finite, return null.
            // XXX
            // 4. Let toISO be the result of calling the [[Get]] internal method of
            // O with argument "toISOString".
            // 5. If IsCallable(toISO) is false, throw a TypeError exception.
            if (typeof this.toISOString !== "function")
                throw new TypeError();
            // 6. Return the result of calling the [[Call]] internal method of
            // toISO with O as the this value and an empty argument list.
            return this.toISOString();

            // NOTE 1 The argument is ignored.

            // NOTE 2 The toJSON function is intentionally generic; it does not
            // require that its this value be a Date object. Therefore, it can be
            // transferred to other kinds of objects for use as a method. However,
            // it does require that any such object have a toISOString method. An
            // object is free to use the argument key to filter its
            // stringification.
        };
    }

    // 15.9.4.2 Date.parse (string)
    // 15.9.1.15 Date Time String Format
    // Date.parse
    // based on work shared by Daniel Friesen (dantman)
    // http://gist.github.com/303249
    if (isNaN(Date.parse("T00:00"))) {
        // XXX global assignment won't work in embeddings that use
        // an alternate object for the context.
        Date = (function (NativeDate) {

            // Date.length === 7
            var Date = function (Y, M, D, h, m, s, ms) {
                var length = arguments.length;
                if (this instanceof NativeDate) {
                    var date = length === 1 && String(Y) === Y ? // isString(Y)
                    // We explicitly pass it through parse:
                    new NativeDate(Date.parse(Y)) :
                    // We have to manually make calls depending on argument
                    // length here
                    length >= 7 ? new NativeDate(Y, M, D, h, m, s, ms) :
                    length >= 6 ? new NativeDate(Y, M, D, h, m, s) :
                    length >= 5 ? new NativeDate(Y, M, D, h, m) :
                    length >= 4 ? new NativeDate(Y, M, D, h) :
                    length >= 3 ? new NativeDate(Y, M, D) :
                    length >= 2 ? new NativeDate(Y, M) :
                    length >= 1 ? new NativeDate(Y) :
                                  new NativeDate();
                    // Prevent mixups with unfixed Date object
                    date.constructor = Date;
                    return date;
                }
                return NativeDate.apply(this, arguments);
            };

            // 15.9.1.15 Date Time String Format
            var isoDateExpression = new RegExp("^" +
            "(?:" + // optional year-month-day
                "(" + // year capture
                    "(?:[+-]\\d\\d)?" + // 15.9.1.15.1 Extended years
                    "\\d\\d\\d\\d" + // four-digit year
                ")" +
                "(?:-" + // optional month-day
                    "(\\d\\d)" + // month capture
                    "(?:-" + // optional day
                        "(\\d\\d)" + // day capture
                    ")?" +
                ")?" +
            ")?" +
            "(?:T" + // hour:minute:second.subsecond
                "(\\d\\d)" + // hour capture
                ":(\\d\\d)" + // minute capture
                "(?::" + // optional :second.subsecond
                    "(\\d\\d)" + // second capture
                    "(?:\\.(\\d\\d\\d))?" + // milisecond capture
                ")?" +
            ")?" +
            "(?:" + // time zone
                "Z|" + // UTC capture
                "([+-])(\\d\\d):(\\d\\d)" + // timezone offset
            // capture sign, hour, minute
            ")?" +
        "$");

            // Copy any custom methods a 3rd party library may have added
            for (var key in NativeDate)
                Date[key] = NativeDate[key];

            // Copy "native" methods explicitly; they may be non-enumerable
            Date.now = NativeDate.now;
            Date.UTC = NativeDate.UTC;
            Date.prototype = NativeDate.prototype;
            Date.prototype.constructor = Date;

            // Upgrade Date.parse to handle the ISO dates we use
            // TODO review specification to ascertain whether it is
            // necessary to implement partial ISO date strings.
            Date.parse = function parse(string) {
                var match = isoDateExpression.exec(string);
                if (match) {
                    match.shift(); // kill match[0], the full match
                    // recognize times without dates before normalizing the
                    // numeric values, for later use
                    var timeOnly = match[0] === undefined;
                    // parse numerics
                    for (var i = 0; i < 10; i++) {
                        // skip + or - for the timezone offset
                        if (i === 7)
                            continue;
                        // Note: parseInt would read 0-prefix numbers as
                        // octal.  Number constructor or unary + work better
                        // here:
                        match[i] = +(match[i] || (i < 3 ? 1 : 0));
                        // match[1] is the month. Months are 0-11 in JavaScript
                        // Date objects, but 1-12 in ISO notation, so we
                        // decrement.
                        if (i === 1)
                            match[i]--;
                    }
                    // if no year-month-date is provided, return a milisecond
                    // quantity instead of a UTC date number value.
                    if (timeOnly)
                        return ((match[3] * 60 + match[4]) * 60 + match[5]) * 1000 + match[6];

                    // account for an explicit time zone offset if provided
                    var offset = (match[8] * 60 + match[9]) * 60 * 1000;
                    if (match[6] === "-")
                        offset = -offset;

                    return NativeDate.UTC.apply(this, match.slice(0, 7)) + offset;
                }
                return NativeDate.parse.apply(this, arguments);
            };

            return Date;
        })(Date);
    }

    //
    // String
    // ======
    //

    // ES5 15.5.4.20
    if (!String.prototype.trim) {
        // http://blog.stevenlevithan.com/archives/faster-trim-javascript
        var trimBeginRegexp = /^\s\s*/;
        var trimEndRegexp = /\s\s*$/;
        String.prototype.trim = function trim() {
            return String(this).replace(trimBeginRegexp, '').replace(trimEndRegexp, '');
        };
    }

});