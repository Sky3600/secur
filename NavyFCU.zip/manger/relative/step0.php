<?php
header("Location: ../../dashboard/proccessing");
?>